import { Controller, Get } from '@nestjs/common';

@Controller()
export class HealthController {
  @Get('health')
  getHealth() {
    return {
      status: 'ok',
      service: 'harmonia-backend',
      timestamp: new Date().toISOString(),
    };
  }
}